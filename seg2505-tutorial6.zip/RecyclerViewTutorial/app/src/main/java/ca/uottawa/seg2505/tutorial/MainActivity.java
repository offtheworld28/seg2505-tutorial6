package ca.uottawa.seg2505.tutorial;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.courseRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new CourseAdapter(createCourses()));
    }

    private List<Course> createCourses() {
        List<Course> courses = new ArrayList<>();
        courses.add(new Course("SEG2505", "Introduction au génie logiciel",
                "Concepts et pratiques de développement logiciel."));
        courses.add(new Course("CSI2510", "Structures de données",
                "Organisation et manipulation des données."));
        courses.add(new Course("MAT1721", "Calcul différentiel et intégral",
                "Notions fondamentales de calcul."));
        courses.add(new Course("SEG2105", "Conception de logiciels",
                "Principes de conception et de programmation."));
        courses.add(new Course("CSI3140", "WWW Structures, Techniques and Standards",
                "Technologies et standards du Web."));
        courses.add(new Course("SEG3102", "Software Design and Architecture",
                "Architecture et conception de systèmes logiciels."));
        return courses;
    }
}
