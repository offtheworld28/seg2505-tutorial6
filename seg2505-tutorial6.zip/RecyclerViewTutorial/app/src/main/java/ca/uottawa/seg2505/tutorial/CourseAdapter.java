package ca.uottawa.seg2505.tutorial;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.CourseViewHolder> {
    private final List<Course> courses;

    public CourseAdapter(List<Course> courses) {
        this.courses = courses;
    }

    @NonNull
    @Override
    public CourseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_course, parent, false);
        return new CourseViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CourseViewHolder holder, int position) {
        Course course = courses.get(position);
        holder.code.setText(course.getCode());
        holder.title.setText(course.getTitle());
        holder.description.setText(course.getDescription());
    }

    @Override
    public int getItemCount() {
        return courses.size();
    }

    static class CourseViewHolder extends RecyclerView.ViewHolder {
        final TextView code;
        final TextView title;
        final TextView description;

        CourseViewHolder(@NonNull View itemView) {
            super(itemView);
            code = itemView.findViewById(R.id.courseCode);
            title = itemView.findViewById(R.id.courseTitle);
            description = itemView.findViewById(R.id.courseDescription);
        }
    }
}
