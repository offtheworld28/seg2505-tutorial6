# SEG2505 – Semaine 5 : RecyclerView (Java)

Projet de départ illustrant une liste dynamique avec `RecyclerView`.

## Ouvrir
1. Décompresser l'archive.
2. Dans Android Studio, choisir **Open** et sélectionner le dossier `seg2505-tutorial6`.
3. Attendre la synchronisation Gradle.
4. Lancer `RecyclerViewTutorial` sur un émulateur ou un appareil Android.

## Contenu
- Liste de cours présentée avec `RecyclerView`
- `CourseAdapter` et `CourseViewHolder`
- Mise en page de chaque ligne dans `item_course.xml`

## À personnaliser / vérifier
- Vérifier la version du SDK installée dans Android Studio.
- Tester le défilement et les rotations portrait/paysage.
- Prendre vos propres captures d'écran après exécution et les insérer dans le rapport Word.
- Créer le dépôt GitHub personnel `seg2505-tutorial6` et pousser le projet, conformément aux consignes du cours.

Ce projet est un exemple de base à valider dans votre environnement Android Studio; les captures d'écran et la démonstration doivent correspondre à votre exécution réelle.
